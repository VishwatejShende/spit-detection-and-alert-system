# Spit-Detection-and-Alert-System

This system uses Dataset from roboflow and YOLOv5 model.
The model was trained using dataset and then used to send messages on telegram is spit is detected.
